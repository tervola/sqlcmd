package ua.com.juja.sqlcmd;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by user on 9/1/2015.
 */
public interface DbController {

    List<String> tableList() throws SQLException;

    List<List<String>> select(String sql) throws SQLException;

    void execute(String sql) throws SQLException;

}
