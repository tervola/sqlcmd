package ua.com.juja.sqlcmd;

import java.sql.Connection;
import java.sql.SQLException;

/**
 * Created by user on 8/28/2015.
 */
public class Controller {

    public static final int WRONG_COMMAND_CODE = 0;
    public static final int EXIT_COMMAND_CODE = -1;
    public static final int VALID_COMMAND_CODE = 1;

    private Configuration configuration;
    private Connection connection;
    private DbController database;
    private PropertiesLoader config;
    private Informer informer;

    public Controller() {
        config = new PropertiesLoader();
        informer = new InformerImpl();
        configuration = config.getConfiguration();
        tryToOpenConnection();
        database = new DbControllerImpl(connection);
    }

    private void tryToOpenConnection() {
        if (config.isUsingScanner()) {
            askConfigurationFromUser();
        }
        do {
            connection = new ConnectionManager(informer).connect(configuration);
            if (connection == null) {
                askConfigurationFromUser();
            }
        } while (connection == null);
    }

    private void askConfigurationFromUser() {
        informer.print("Type credentials to connect to SQL " +
                "server(database|username|password):");
        String credentials = informer.read();
        String[] line = credentials.split("\\|");

        if (line.length == 3) {
            configuration.setDatabaseName(line[0].trim());
            configuration.setUserName(line[1].trim());
            configuration.setPassword(line[2].trim());
        } else {
            informer.print("Wrong input type format!");
        }
    }

    public void run() {
        int code = 0;
        while (code != EXIT_COMMAND_CODE) {
            informer.print("Input command():");
            informer.print("");
            try {
                code = parser(informer.read());
            } catch (SQLException error) {
                errorHandler(error);
            }
            if (code == WRONG_COMMAND_CODE) {
                informer.print("Try again or type \"help\"");
            }
        }
        closeConnection();
    }

    private void closeConnection() {
        try {
            connection.close();
        } catch (SQLException e) {
            informer.print("Error closing exception");
        }
    }

    private void errorHandler(SQLException error) {
        String[] errorMessage = error.getMessage().split("\n");

        for (int i = 0; i < errorMessage.length - 1; i++) {
            informer.print(errorMessage[i] + ". ");
        }
    }

    private int parser(String command) throws SQLException {
        if (command.trim().length() == 0 || command.isEmpty()) {
            return WRONG_COMMAND_CODE;
        }
        command = command.toLowerCase();

        if (command.equals("help")) {
            informer.help();
        } else if (command.equals("exit")) {
            informer.print("Closing connection...");
            return EXIT_COMMAND_CODE;
        } else if (command.equals("list")) {
            informer.print(String.format("List of tables in database: " +
                            "%s, on the server: %s:%s",
                    configuration.getDatabaseName(),
                    configuration.getServerName(),
                    configuration.getPortNumber()));
            int index = 1;
            for (String row : database.tableList()) {
                informer.print(String.valueOf(index++) + "." + row);
            }
        } else if (command.startsWith("select")) {
            informer.print(String.format("Result: \"%s\"", command));
            informer.printTable(database.select(command));
        } else {
            database.execute(command);
            informer.print(String.format("%s command was successfully!!!",
                    command.split(" ")[0]));
        }
        return VALID_COMMAND_CODE;
    }
}
