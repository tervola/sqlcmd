package ua.com.juja.sqlcmd;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by user on 9/15/2015.
 */
public interface Informer {
    void help();

    void print(String string);

    void printTable(List<List<String>> table);

    String read();
}
