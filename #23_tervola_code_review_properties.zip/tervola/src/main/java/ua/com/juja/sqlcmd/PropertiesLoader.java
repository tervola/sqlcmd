package ua.com.juja.sqlcmd;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Properties;

/**
 * Created by oleksandr.baglai on 25.09.2015.
 */
public class PropertiesLoader {

    public static final String CONFIG_SQLCMD_PROPERTIES = "config/sqlcmd.properties";
    private Properties properties;

    public PropertiesLoader() {
        FileInputStream fileInput = null;
        properties = new Properties();
        File file = new File(CONFIG_SQLCMD_PROPERTIES);
        try {
            fileInput = new FileInputStream(file);
            properties.load(fileInput);
        } catch (Exception e) {
            System.out.println("Error loading config " + file.getAbsolutePath());
            e.printStackTrace();
        } finally {
            if (fileInput != null) {
                try {
                    fileInput.close();
                } catch (IOException e) {
                    // do nothing;
                }
            }
        }
    }

    public Configuration getConfiguration() {
        return new Configuration(
                getDatabaseName(),
                getServerName(),
                getPort(),
                getUserName(),
                getDriver(),
                getPassword()
        );
    }

    private String getServerName() {
        return properties.getProperty("database.server.name");
    }

    private String getDatabaseName() {
        return properties.getProperty("database.name");
    }

    private String getPort() {
        return properties.getProperty("database.port");
    }

    private String getDriver() {
        return properties.getProperty("database.jdbc.driver");
    }

    private String getUserName() {
        return properties.getProperty("database.user.name");
    }

    private String getPassword() {
        return properties.getProperty("database.user.password");
    }

    public boolean isUsingScanner() {
        String property = properties.getProperty("sqlcmd.usingScanner");

        return property != null && property.equals(true);
    }

}
