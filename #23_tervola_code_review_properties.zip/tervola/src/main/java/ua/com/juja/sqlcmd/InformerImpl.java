package ua.com.juja.sqlcmd;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * Created by user on 9/15/2015.
 */
public class InformerImpl implements Informer {

    public InformerImpl() {
        print("Type \"help\" for command list or type command: ");
    }

    @Override
    public void help() {
        print(
                "\t" + "help: \n\t\tShow this help" + "\n" +
                "\t" + "exit: \n\t\tOutput from the program" + "\n" +
                "\t" + "list: \n" +
                "\t\tList of tables into the database" + "\n" +
                "\t" + "Select from table: \n" +
                "\t\tSelect records from table, examples:" + "\n" +
                "\t\t" + " \"SELECT * FROM name\"" + "\n" +
                "\t\t" + " \"SELECT * FROM name WHERE id > 1\"" + "\n" +
                "\t\t" + " \"SELECT id FROM name WHERE id < 1\"" + "\n" +
                "\t" + "Insert into table: \n" +
                "\t\t" + " \"INSERT INTO id (id_name,id_temp,country_name) VALUES (3, 'tree', 'UA');\"" + "\n" +
                "\t\t" + " \"INSERT INTO employee (id,name,alias) VALUES (1, 'Stas', 'tervola');\"" + "\n" +
                "\t" + "Updating records: \n" +
                "\t\tupdating records into table" + "\n" +
                "\t\t" + " \"UPDATE id set country_name = 'Unknown' WHERE country_name ='null';\"" + "\n" +
                "\t" + "Deleting records: \n" +
                "\t\t" + " \"DELETE FROM id WHERE id_name = 4;\"" + "\n" +
                "\t" + "drop: \n" +
                "\t\t\"DROP TABLE films, distributors;\"" + "\n" +
                "\t" + "Create table: \n" +
                "\t\t" + " \"CREATE TABLE COMPANY (ID INT, NAME TEXT NOT NULL, AGE INT NOT NULL)\";"
        );
    }

    @Override
    public void print(String string) {
        System.out.println(string);
    }

    @Override
    public void printTable(List<List<String>> table) {
        for (List<String> line : table) {
            String formatter = createFormatter(line.size());
            print(String.format(formatter, line.get(0), line.get(1), line.get(2)));
        }
    }

    @Override
    public String read() {
        return new Scanner(System.in).nextLine();
    }

    private String createFormatter(int count) {
        String formatter = "|";
        for (int i = 0; i < count; i++) {
            formatter += " %15s |";
        }
        return formatter + "\n";
    }

}
