package ua.com.juja.sqlcmd;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 * Created by user on 8/28/2015.
 */
public class DbControllerImpl implements DbController {

    private Connection connection;

    public DbControllerImpl(Connection connection) {
        this.connection = connection;
    }

    @Override
    public List<String> tableList() throws SQLException {
        List<String> result = new ArrayList<>();
        DatabaseMetaData md = connection.getMetaData();
        ResultSet rs = md.getTables(null, "public", null, null);
        while (rs.next()) {
            result.add(rs.getString(3));
        }
        return result;
    }

    @Override
    public List<List<String>> select(String sql) throws SQLException {
        try (Statement stmt = connection.createStatement()) {
            try (ResultSet rs = stmt.executeQuery(sql)) {
                return createTable(rs);
            }
        }
    }

    @Override
    public void execute(String sql) throws SQLException {
        doUpdateExecution(sql);
    }

    public void doUpdateExecution(String sql) throws SQLException {
        try (Statement stmt = connection.createStatement()) {
            stmt.executeUpdate(sql);
        }
    }

    private List<List<String>> createTable(ResultSet resultSet) throws SQLException {
        List<List<String>> result = new ArrayList<>();
        int columnCount = resultSet.getMetaData().getColumnCount();
        if (columnCount < 0) {
            return null;
        }

        result.add(createTitle(resultSet, columnCount));

        while (resultSet.next()) {
            result.add(createBody(resultSet, columnCount));
        }
        return result;
    }

    private List<String> createTitle(ResultSet resultSet, int columnCount) throws SQLException {
        List<String> result = new ArrayList<>(columnCount);

        for (int i = 0; i < columnCount; i++) {
            result.add(resultSet.getMetaData().getColumnName(i + 1));
        }
        return result;
    }

    private List<String> createBody(ResultSet resultSet, int columnCount) throws SQLException {
        List<String> result = new ArrayList<>(columnCount);

        for (int i = 0; i < columnCount; i++) {
            result.add(resultSet.getString(i + 1));
        }
        return result;
    }
}
