package ua.com.juja.sqlcmd;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 * Created by user on 9/18/2015.
 */
public class ConnectionManager {

    private Informer informer;
    private Connection connection;

    public ConnectionManager(Informer informer) {
        this.informer = informer;
    }

    public Connection connect(Configuration configuration) {
        if (connection == null) {
            try {
                String url = String.format("%s%s:%s/%s",
                        configuration.getDriver(),
                        configuration.getServerName(),
                        configuration.getPortNumber(),
                        configuration.getDatabaseName());

                connection = DriverManager.getConnection(url,
                        configuration.getUserName(),
                        configuration.getPassword());

                informer.print(String.format("Opened database %s successfully",
                        configuration.getDatabaseName()));
            } catch (Exception e) {
                informer.print(e.getClass().getName() + ": " + e.getMessage());
            }
        }
        return connection;
    }
}
